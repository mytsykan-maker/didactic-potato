# Карта технических символов

| № | Unicode | Escape для JSON | Символ | Файл |
|---:|---|---|:---:|---|
| 0 | U+E000 | `\uE000` |  | `builder.png` |
| 1 | U+E001 | `\uE001` |  | `curator.png` |
| 2 | U+E002 | `\uE002` |  | `dev.png` |
| 3 | U+E003 | `\uE003` |  | `eventmaster.png` |
| 4 | U+E004 | `\uE004` |  | `glmoderator.png` |
| 5 | U+E005 | `\uE005` |  | `helper.png` |
| 6 | U+E006 | `\uE006` |  | `media.png` |
| 7 | U+E007 | `\uE007` |  | `moderator.png` |
| 8 | U+E008 | `\uE008` |  | `prezident.png` |
| 9 | U+E009 | `\uE009` |  | `rank_admin1.png` |
| 10 | U+E00A | `\uE00A` |  | `rank_production.png` |
| 11 | U+E00B | `\uE00B` |  | `senior_helper.png` |
| 12 | U+E00C | `\uE00C` |  | `senior_moderatior.png` |
| 13 | U+E00D | `\uE00D` |  | `sponsor.png` |
| 14 | U+E00E | `\uE00E` |  | `vip.png` |
| 15 | U+E00F | `\uE00F` |  | `voenkor.png` |

Все glyphs настроены с `height: 8` и `ascent: 7`, чтобы суффиксы помещались в обычную строку Minecraft. Исходные PNG скопированы без изменения.

```mcfunction
/tellraw @s {"text":"\uE000 \uE001 \uE002 \uE003 \uE004 \uE005 \uE006 \uE007 \uE008 \uE009 \uE00A \uE00B \uE00C \uE00D \uE00E \uE00F"}
```
