MoonFall suffix glyphs

This resource pack contains the custom font glyphs used for player suffixes/ranks.
The server must insert the corresponding Unicode character into chat/tab text.
The mapping is in assets/minecraft/font/suffixes.json.

Minecraft 1.21.x (pack format 34). The five rarity glyphs reference the included
bloodstone texture at assets/bloodstone/textures/ui/tag/rarities.png.
