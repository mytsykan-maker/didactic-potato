# CustomGlyphs — suffixes

Resource pack для Minecraft Java Edition 1.21.11 (`pack_format: 75`). Он добавляет 16 изображений из папки `suffixes` в стандартный шрифт `minecraft:default` через bitmap font providers.

Полная таблица «Unicode → PNG» находится в `GLYPH-MAP.md`.

## Установка

Положите `CustomGlyphs-1.0.0.zip` в `.minecraft/resourcepacks` и включите пак. Для Paper-сервера разместите ZIP по прямой HTTP(S)-ссылке и задайте её через `resource-pack` в `server.properties`.

## Файлы

- PNG: `assets/minecraft/textures/font/glyphs/`
- Providers: `assets/minecraft/font/default.json`
- Карта символов: `GLYPH-MAP.md`

Все исходные PNG скопированы без изменения. Для каждого glyph выставлены `height: 8` и `ascent: 7`. При необходимости эти два значения можно менять отдельно у каждого объекта в `default.json`.

## Использование

Символ можно вставлять непосредственно в текст либо записывать JSON escape. Например, `builder.png`:

```mcfunction
/tellraw @a {"text":"Суффикс: \uE000"}
```

То же с непосредственным символом:

```mcfunction
/tellraw @a {"text":"Суффикс: "}
```

После изменения пака используйте `F3+T` для перезагрузки ресурсов.
